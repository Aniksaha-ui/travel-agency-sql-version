const responseFormat = {
  isExecute: "",
  data: "",
  message: "",
};

module.exports = responseFormat;
